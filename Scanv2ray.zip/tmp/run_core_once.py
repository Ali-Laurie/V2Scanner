import time, subprocess, os
from pathlib import Path
from scanv2ray import parser, configs
from scanv2ray.scanner import get_free_port

link = 'vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogIkBXaGl0ZU5ldF9uZXcg2KzZh9iqINqp2KfZhtmB24zaryDZh9in24wg2KjbjNi02KrYsSDYrNmI24zZhiDYtNmIIiwNCiAgImFkZCI6ICIxNzIuMjMyLjEwMy4xODYiLA0KICAicG9ydCI6ICIyMjMyNCIsDQogICJpZCI6ICIwNDYyMWJhZS1hYjM2LTExZWMtYjkwOS0wMjQyYWMxMjAwMDIiLA0KICAiYWlkIjogIjAiLA0KICAic2N5IjogImF1dG8iLA0KICAibmV0IjogInRjcCIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICIiLA0KICAicGF0aCI6ICIiLA0KICAidGxzIjogIiIsDQogICJzbmkiOiAiIiwNCiAgImFscG4iOiAiIiwNCiAgImZwIjogIiIsDQogICJpbnNlY3VyZSI6ICIwIg0KfQ=='
parsed = parser.parse_link(link)
print('parsed=', parsed)
if not parsed:
    raise SystemExit('parse failed')
local_port = get_free_port()
print('local_port', local_port)
config = configs.make_xray_config(parsed, local_port)
print('config built')
script_dir = Path(__file__).parent / 'scanv2ray'
xray = str(script_dir.parent / 'Core' / 'xray' / 'xray.exe')
config_path = str((script_dir.parent / 'Core' / f'temp_test_{int(time.time())}.json').resolve())
with open(config_path, 'w', encoding='utf-8') as f:
    import json
    json.dump(config, f)
print('wrote', config_path)

args = [xray, '-c', config_path]
print('running', args)
proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
print('pid', proc.pid)
# wait a short time and read any output
time.sleep(1.0)
try:
    out = proc.stdout.read().decode('utf-8', errors='ignore')
    err = proc.stderr.read().decode('utf-8', errors='ignore')
    print('stdout:', out)
    print('stderr:', err)
except Exception as e:
    print('read error', e)

# check port
import socket
s = socket.socket()
try:
    s.settimeout(1.0)
    s.connect(('127.0.0.1', local_port))
    print('connected to local port')
    s.close()
except Exception as e:
    print('connect failed:', e)

# cleanup
proc.terminate()
try:
    proc.wait(timeout=2)
except Exception:
    proc.kill()

try:
    os.remove(config_path)
except Exception:
    pass
print('done')
