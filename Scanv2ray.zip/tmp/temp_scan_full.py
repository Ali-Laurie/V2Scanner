from pathlib import Path
from scanv2ray.scanner import Scanner

file_path = Path('D:/sub-test.txt')
if not file_path.exists():
    raise FileNotFoundError(file_path)

xray = Path('Core/xray/xray.exe')
sing = Path('Core/sing_box/sing-box.exe')
scanner = Scanner(str(xray), str(sing))
links = [line.strip() for line in file_path.read_text(encoding='utf-8', errors='ignore').splitlines() if line.strip()]
print('TOTAL LINKS:', len(links))
results = []

for idx, link in enumerate(links, start=1):
    print(f'[{idx}/{len(links)}] testing:', link)
    try:
        res = scanner.process_link(link, timeout=6, methods=['fast'])
    except Exception as e:
        print('  EXCEPTION:', e)
        res = []
    if res:
        print('  OK:', res)
    else:
        print('  DEAD')
    if res:
        results.append((link, res))

print('\n=== SUMMARY ===')
print('success_count:', len(results))
for link, res in results:
    print(link)
    print(res)
