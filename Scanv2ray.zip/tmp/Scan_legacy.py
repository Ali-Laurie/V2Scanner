import customtkinter as ctk
from tkinter import filedialog
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import os
import re
import socket
import ssl
import base64
import json
import time
import urllib.request
from urllib.parse import urlparse, unquote, parse_qs

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Regex to match vmess, vless, trojan, and ss links, excluding quotes and surrounding whitespace
LINK_RE = re.compile(
    r'(vmess://[^\s\'"]+|vless://[^\s\'"]+|trojan://[^\s\'"]+|ss://[^\s\'"]+)'
)


def try_decode_base64_content(content):
    """
    Attempts to decode base64 encoded subscription content.
    Returns the decoded string if it contains VPN configurations, otherwise returns the original content.
    """
    clean_content = re.sub(r'\s+', '', content)
    if not clean_content:
        return content
    try:
        # Add padding if missing
        missing_padding = len(clean_content) % 4
        if missing_padding:
            clean_content += '=' * (4 - missing_padding)
        
        decoded = base64.b64decode(clean_content).decode('utf-8', errors='ignore')
        # Check if the decoded content contains valid protocols
        if any(proto in decoded for proto in ["vmess://", "vless://", "ss://", "trojan://"]):
            return decoded
    except Exception:
        pass
    return content


def get_free_port():
    """
    Binds to a port of 0 to let the OS assign a free port, then releases it.
    """
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


def build_xray_stream_settings(transport_type, host_header, path, security_mode, sni):
    stream_settings = {
        "network": transport_type or "tcp",
        "security": security_mode or "none"
    }

    if security_mode in ["tls", "xtls"]:
        if security_mode == "xtls":
            stream_settings["xtlsSettings"] = {
                "serverName": sni or host_header or "",
                "allowInsecure": True,
                "alpn": ["h2", "http/1.1"]
            }
        else:
            stream_settings["tlsSettings"] = {
                "serverName": sni or host_header or "",
                "allowInsecure": True
            }

    if transport_type == "ws":
        stream_settings["wsSettings"] = {
            "path": path or "/",
            "headers": {
                "Host": host_header or ""
            }
        }
    elif transport_type == "grpc":
        stream_settings["grpcSettings"] = {
            "serviceName": path or ""
        }
    elif transport_type == "h2":
        stream_settings["httpSettings"] = {
            "path": path or "/",
            "host": [host_header or sni or ""]
        }
    elif transport_type == "quic":
        stream_settings["quicSettings"] = {
            "security": "none",
            "key": "",
            "header": {"type": "none"}
        }
    elif transport_type == "kcp":
        stream_settings["kcpSettings"] = {
            "mtu": 1350,
            "tti": 20,
            "uplinkCapacity": 5,
            "downlinkCapacity": 20,
            "congestion": False,
            "readBufferSize": 1,
            "writeBufferSize": 1,
            "header": {"type": "none"}
        }

    return stream_settings


def make_xray_config(proto, host, port, credentials, security_mode, is_tls, sni, transport_type, path, host_header, local_port, flow=""):
    """
    Generates a client config JSON dictionary for Xray core.
    """
    config = {
        "log": {"loglevel": "none"},
        "inbounds": [
            {
                "port": local_port,
                "listen": "127.0.0.1",
                "protocol": "http"
            }
        ],
        "outbounds": []
    }
    
    outbound = {
        "protocol": proto,
        "settings": {},
        "streamSettings": build_xray_stream_settings(transport_type, host_header, path, security_mode if is_tls else "none", sni)
    }
    
    if proto == "vmess":
        outbound["settings"] = {
            "vnext": [
                {
                    "address": host,
                    "port": port,
                    "users": [
                        {
                            "id": credentials,
                            "alterId": 0,
                            "security": "auto"
                        }
                    ]
                }
            ]
        }
    elif proto == "vless":
        user_obj = {
            "id": credentials,
            "encryption": "none"
        }
        if flow:
            user_obj["flow"] = flow
        outbound["settings"] = {
            "vnext": [
                {
                    "address": host,
                    "port": port,
                    "users": [user_obj]
                }
            ]
        }
    elif proto == "trojan":
        outbound["settings"] = {
            "servers": [
                {
                    "address": host,
                    "port": port,
                    "password": credentials
                }
            ]
        }
    elif proto == "ss":
        method, password = credentials.split(":", 1) if ":" in credentials else ("aes-256-gcm", credentials)
        outbound["settings"] = {
            "servers": [
                {
                    "address": host,
                    "port": port,
                    "method": method,
                    "password": password
                }
            ]
        }
        
    config["outbounds"].append(outbound)
    return config


def make_singbox_config(proto, host, port, credentials, security_mode, is_tls, sni, transport_type, path, host_header, local_port, flow=""):
    """
    Generates a client config JSON dictionary for Sing-box core.
    """
    config = {
        "log": {"level": "panic"},
        "inbounds": [
            {
                "type": "http",
                "listen": "127.0.0.1",
                "listen_port": local_port
            }
        ],
        "outbounds": []
    }
    
    outbound = {
        "tag": "proxy",
        "server": host,
        "server_port": port
    }
    
    if proto == "ss":
        outbound["type"] = "shadowsocks"
        method, password = credentials.split(":", 1) if ":" in credentials else ("aes-256-gcm", credentials)
        outbound["method"] = method
        outbound["password"] = password
    elif proto == "vmess":
        outbound["type"] = "vmess"
        outbound["uuid"] = credentials
        outbound["alter_id"] = 0
        outbound["security"] = "auto"
    elif proto == "vless":
        outbound["type"] = "vless"
        outbound["uuid"] = credentials
        if flow:
            outbound["flow"] = flow
    elif proto == "trojan":
        outbound["type"] = "trojan"
        outbound["password"] = credentials
        
    if is_tls:
        outbound["tls"] = {
            "enabled": True,
            "server_name": sni or host,
            "insecure": True
        }
        
    if transport_type == "ws":
        outbound["transport"] = {
            "type": "ws",
            "path": path or "/",
            "headers": {
                "Host": host_header or sni or host or ""
            }
        }
    elif transport_type == "grpc":
        outbound["transport"] = {
            "type": "grpc",
            "service_name": path or ""
        }
    elif transport_type == "h2":
        outbound["transport"] = {
            "type": "http",
            "path": path or "/",
            "headers": {
                "Host": host_header or sni or host or ""
            }
        }
    elif transport_type == "quic":
        outbound["transport"] = {
            "type": "quic",
            "security": "none",
            "key": "",
            "header": {
                "type": "none"
            }
        }
    elif transport_type == "kcp":
        outbound["transport"] = {
            "type": "kcp",
            "header": {
                "type": "none"
            }
        }
        
    config["outbounds"].append(outbound)
    return config


class ConfigScannerApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("XrayScanner | Alibakhtiari")
        self.geometry("700x920")
        self.resizable(False, False)

        self.folder_path = None
        self.loader_running = False
        
        self.fast_links = []
        self.normal_links = []
        self.fast_nodes = []
        self.normal_nodes = []

        # Scan States: "idle", "running", "paused", "stopping", "stopping_save"
        self.scan_state = "idle"
        self.pause_cond = threading.Condition()

        # --- Top Header ---
        self.header_label = ctk.CTkLabel(
            self, 
            text="XrayScanner | Alibakhtiari", 
            font=ctk.CTkFont(family="Helvetica", size=20, weight="bold")
        )
        self.header_label.pack(pady=(15, 5))

        # --- Settings Frame ---
        self.settings_frame = ctk.CTkFrame(self)
        self.settings_frame.pack(pady=10, padx=20, fill="x")

        # Column 0: Thread count
        self.threads_label = ctk.CTkLabel(self.settings_frame, text="Threads:", font=ctk.CTkFont(size=12))
        self.threads_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        self.threads_entry = ctk.CTkEntry(self.settings_frame, width=70)
        self.threads_entry.insert(0, "80")
        self.threads_entry.grid(row=0, column=1, padx=5, pady=10)

        # Column 1: Timeout
        self.timeout_label = ctk.CTkLabel(self.settings_frame, text="Timeout (s):", font=ctk.CTkFont(size=12))
        self.timeout_label.grid(row=0, column=2, padx=10, pady=10, sticky="w")
        self.timeout_entry = ctk.CTkEntry(self.settings_frame, width=70)
        self.timeout_entry.insert(0, "3")
        self.timeout_entry.grid(row=0, column=3, padx=5, pady=10)

        # Column 2: File Filter Combo Box
        self.filter_label = ctk.CTkLabel(self.settings_frame, text="File Filter:", font=ctk.CTkFont(size=12))
        self.filter_label.grid(row=0, column=4, padx=10, pady=10, sticky="w")
        self.filter_combo = ctk.CTkComboBox(self.settings_frame, values=["All .txt files", "Only sub*.txt files"], width=150)
        self.filter_combo.set("All .txt files")
        self.filter_combo.grid(row=0, column=5, padx=5, pady=10)

        # Row 1: Test Mode
        self.mode_label = ctk.CTkLabel(self.settings_frame, text="Test Mode:", font=ctk.CTkFont(size=12))
        self.mode_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")
        self.mode_combo = ctk.CTkComboBox(
            self.settings_frame, 
            values=["TCP / TLS (Ultra Fast)", "Xray Core (Real Delay & Speed)", "Sing-box Core (Real Delay & Speed)"], 
            width=300,
            command=self.on_mode_change
        )
        self.mode_combo.set("TCP / TLS (Ultra Fast)")
        self.mode_combo.grid(row=1, column=1, columnspan=4, padx=5, pady=10, sticky="w")

        # --- Action Buttons Frame ---
        self.actions_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.actions_frame.pack(pady=5, padx=20, fill="x")

        self.select_button = ctk.CTkButton(
            self.actions_frame, 
            text="📁 Select Folder", 
            command=self.select_folder,
            font=ctk.CTkFont(weight="bold")
        )
        self.select_button.pack(side="left", expand=True, fill="x", padx=5)

        self.start_button = ctk.CTkButton(
            self.actions_frame, 
            text="🚀 Start Scan (PRO)", 
            command=self.start_scan, 
            state="disabled",
            font=ctk.CTkFont(weight="bold")
        )
        self.start_button.pack(side="right", expand=True, fill="x", padx=5)

        # --- Scan Controls Frame (Pause, Stop, Stop & Save) ---
        self.controls_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.controls_frame.pack(pady=5, padx=20, fill="x")
        
        self.pause_button = ctk.CTkButton(
            self.controls_frame, 
            text="⏸️ Pause", 
            command=self.toggle_pause,
            state="disabled",
            fg_color="#e67e22",
            hover_color="#d35400",
            font=ctk.CTkFont(weight="bold")
        )
        self.pause_button.pack(side="left", expand=True, fill="x", padx=5)

        self.stop_save_button = ctk.CTkButton(
            self.controls_frame, 
            text="💾 Stop & Save", 
            command=self.stop_and_save,
            state="disabled",
            fg_color="#2980b9",
            hover_color="#2471a3",
            font=ctk.CTkFont(weight="bold")
        )
        self.stop_save_button.pack(side="left", expand=True, fill="x", padx=5)

        self.stop_button = ctk.CTkButton(
            self.controls_frame, 
            text="🛑 Stop (Cancel)", 
            command=self.stop_scan_now,
            state="disabled",
            fg_color="#c0392b",
            hover_color="#962d22",
            font=ctk.CTkFont(weight="bold")
        )
        self.stop_button.pack(side="left", expand=True, fill="x", padx=5)

        # --- Progress & Status ---
        self.status = ctk.CTkLabel(
            self, 
            text="Ready", 
            font=ctk.CTkFont(size=12, slant="italic")
        )
        self.status.pack(pady=(10, 2))

        self.progress_bar = ctk.CTkProgressBar(self, width=600)
        self.progress_bar.set(0)
        self.progress_bar.pack(pady=(2, 10))

        # --- Stats & Copy Panel ---
        self.stats_frame = ctk.CTkFrame(self)
        self.stats_frame.pack(pady=5, padx=20, fill="x")
        
        # Configure columns for Stats Frame
        self.stats_frame.columnconfigure((0, 1, 2), weight=1)
        
        # Live Stats Labels
        self.fast_label = ctk.CTkLabel(
            self.stats_frame, 
            text="Fast (<200ms): 0", 
            text_color="#2ecc71", 
            font=ctk.CTkFont(weight="bold")
        )
        self.fast_label.grid(row=0, column=0, padx=10, pady=10)

        self.normal_label = ctk.CTkLabel(
            self.stats_frame, 
            text="Normal (200-800ms): 0", 
            text_color="#f39c12", 
            font=ctk.CTkFont(weight="bold")
        )
        self.normal_label.grid(row=0, column=1, padx=10, pady=10)

        self.offline_label = ctk.CTkLabel(
            self.stats_frame, 
            text="Offline: 0", 
            text_color="#e74c3c", 
            font=ctk.CTkFont(weight="bold")
        )
        self.offline_label.grid(row=0, column=2, padx=10, pady=10)

        # --- Copy Buttons Frame ---
        self.copy_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.copy_frame.pack(pady=5, padx=20, fill="x")
        
        self.copy_fast_btn = ctk.CTkButton(
            self.copy_frame, 
            text="📋 Copy Fast", 
            command=self.copy_fast,
            state="disabled",
            font=ctk.CTkFont(weight="bold")
        )
        self.copy_fast_btn.pack(side="left", expand=True, fill="x", padx=5)

        self.copy_normal_btn = ctk.CTkButton(
            self.copy_frame, 
            text="📋 Copy Normal", 
            command=self.copy_normal,
            state="disabled",
            font=ctk.CTkFont(weight="bold")
        )
        self.copy_normal_btn.pack(side="left", expand=True, fill="x", padx=5)

        self.copy_all_btn = ctk.CTkButton(
            self.copy_frame, 
            text="📋 Copy All Active", 
            command=self.copy_all_active,
            state="disabled",
            font=ctk.CTkFont(weight="bold")
        )
        self.copy_all_btn.pack(side="left", expand=True, fill="x", padx=5)

        # --- Output Log Textbox ---
        self.box = ctk.CTkTextbox(self, width=660, height=180)
        self.box.pack(pady=(5, 5), padx=20)

        # --- Steps Guide Frame ---
        self.steps_frame = ctk.CTkFrame(self)
        self.steps_frame.pack(pady=(5, 10), padx=20, fill="x")

        steps_title = ctk.CTkLabel(
            self.steps_frame,
            text="📖 Scan Steps Guide",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            anchor="w"
        )
        steps_title.pack(pady=(8, 4), padx=10, anchor="w")

        steps_text = (
            "1. Select the folder containing configuration (.txt) files\n"
            "2. Set the number of Threads and Timeout value\n"
            "3. Choose test mode (Fast TCP or Accurate Xray/Sing-box)\n"
            "4. Click Start Scan and wait for results\n"
            "5. Active configurations will be displayed with latency and speed details\n"
            "6. Copy results or retrieve them from the Scan_Results folder"
        )

        steps_label = ctk.CTkLabel(
            self.steps_frame,
            text=steps_text,
            font=ctk.CTkFont(family="Tahoma", size=11),
            justify="right",
            anchor="w"
        )
        steps_label.pack(pady=(0, 8), padx=10, anchor="w")

    # ---------------- UI SAFE UPDATES ----------------
    def log(self, text):
        self.after(0, lambda: self._log(text))

    def _log(self, text):
        self.box.insert("end", text + "\n")
        self.box.see("end")
        
        # Write to log file if folder_path is selected
        if self.folder_path:
            log_dir = os.path.join(self.folder_path, "Scan_Results")
            try:
                os.makedirs(log_dir, exist_ok=True)
                log_filepath = os.path.join(log_dir, "scan_log.txt")
                timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                with open(log_filepath, "a", encoding="utf-8") as f:
                    f.write(f"[{timestamp}] {text}\n")
            except:
                pass

    def set_status(self, text):
        self.after(0, lambda: self.status.configure(text=text))

    def set_progress(self, value):
        self.after(0, lambda: self.progress_bar.set(value))

    def set_button_states(self, start_state, select_state):
        self.after(0, lambda: self.start_button.configure(state=start_state))
        self.after(0, lambda: self.select_button.configure(state=select_state))

    def on_mode_change(self, choice):
        if "Core" in choice:
            self.threads_entry.delete(0, "end")
            self.threads_entry.insert(0, "15")
            self.log("💡 Suggestion: Lowered thread count to 15 for core testing to prevent high CPU usage.")
        else:
            self.threads_entry.delete(0, "end")
            self.threads_entry.insert(0, "80")

    def update_live_stats(self, fast, normal, offline):
        self.after(0, lambda: self._update_live_stats(fast, normal, offline))

    def _update_live_stats(self, fast, normal, offline):
        self.fast_label.configure(text=f"Fast (<200ms): {fast}")
        self.normal_label.configure(text=f"Normal (200-800ms): {normal}")
        self.offline_label.configure(text=f"Offline: {offline}")

    def set_copy_buttons_state(self, state):
        self.after(0, lambda: self._set_copy_buttons_state(state))

    def _set_copy_buttons_state(self, state):
        self.copy_fast_btn.configure(state=state)
        self.copy_normal_btn.configure(state=state)
        self.copy_all_btn.configure(state=state)

    def set_control_buttons_state(self, pause_state, stop_save_state, stop_state):
        self.after(0, lambda: self._set_control_buttons_state(pause_state, stop_save_state, stop_state))

    def _set_control_buttons_state(self, pause_state, stop_save_state, stop_state):
        self.pause_button.configure(state=pause_state)
        self.stop_save_button.configure(state=stop_save_state)
        self.stop_button.configure(state=stop_state)

    def copy_fast(self):
        if self.fast_links:
            text = "\n".join(self.fast_links)
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update()
            self.log("📋 Copied fast configs to clipboard!")
        else:
            self.log("⚠️ No fast configs to copy.")

    def copy_normal(self):
        if self.normal_links:
            text = "\n".join(self.normal_links)
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update()
            self.log("📋 Copied normal configs to clipboard!")
        else:
            self.log("⚠️ No normal configs to copy.")

    def copy_all_active(self):
        all_links = self.fast_links + self.normal_links
        if all_links:
            text = "\n".join(all_links)
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update()
            self.log("📋 Copied all active configs to clipboard!")
        else:
            self.log("⚠️ No active configs to copy.")

    # ---------------- CONTROLS ----------------
    def toggle_pause(self):
        if self.scan_state == "running":
            self.scan_state = "paused"
            self.pause_button.configure(text="▶️ Resume", fg_color="#2ecc71", hover_color="#27ae60")
            self.log("⏸️ Scan paused.")
            self.set_status("Scan paused")
        elif self.scan_state == "paused":
            self.scan_state = "running"
            self.pause_button.configure(text="⏸️ Pause", fg_color="#e67e22", hover_color="#d35400")
            self.log("▶️ Scan resumed.")
            self.set_status("Scan resumed")
            with self.pause_cond:
                self.pause_cond.notify_all()

    def stop_scan_now(self):
        self.scan_state = "stopping"
        self.log("🛑 Stopping scan and discarding results...")
        self.set_status("Stopping...")
        self.set_control_buttons_state("disabled", "disabled", "disabled")
        with self.pause_cond:
            self.pause_cond.notify_all()

    def stop_and_save(self):
        self.scan_state = "stopping_save"
        self.log("💾 Stopping scan and saving progress...")
        self.set_status("Saving progress...")
        self.set_control_buttons_state("disabled", "disabled", "disabled")
        with self.pause_cond:
            self.pause_cond.notify_all()

    def check_pause_and_stop(self):
        if self.scan_state in ["stopping", "stopping_save"]:
            return False
            
        if self.scan_state == "paused":
            with self.pause_cond:
                while self.scan_state == "paused":
                    self.pause_cond.wait(timeout=0.5)
                    
        if self.scan_state in ["stopping", "stopping_save"]:
            return False
            
        return True

    # ---------------- FOLDER ----------------
    def select_folder(self):
        self.folder_path = filedialog.askdirectory()
        if self.folder_path:
            self.set_status(f"Folder: {self.folder_path}")
            self.start_button.configure(state="normal")

    # ---------------- START ----------------
    def start_scan(self):
        self.box.delete("1.0", "end")
        
        # Clear/Create log file for the new scan session
        if self.folder_path:
            log_dir = os.path.join(self.folder_path, "Scan_Results")
            try:
                os.makedirs(log_dir, exist_ok=True)
                log_filepath = os.path.join(log_dir, "scan_log.txt")
                with open(log_filepath, "w", encoding="utf-8") as f:
                    f.write(f"=== XrayScanner SCAN LOG STARTED AT {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            except:
                pass

        self.log("🚀 Starting PRO scan...")
        self.set_progress(0)
        self.set_button_states("disabled", "disabled")
        self.set_copy_buttons_state("disabled")
        self.fast_links = []
        self.normal_links = []
        self.fast_nodes = []
        self.normal_nodes = []
        self.update_live_stats(0, 0, 0)
        
        # Reset scan controls state
        self.scan_state = "running"
        self.pause_button.configure(text="⏸️ Pause", fg_color="#e67e22", hover_color="#d35400")
        self.set_control_buttons_state("normal", "normal", "normal")
        
        threading.Thread(target=self.run_scan, daemon=True).start()

    # ---------------- CORE SCAN ----------------
    def run_scan(self):
        executor = None
        try:
            # 1. Parse settings safely
            try:
                max_workers = int(self.threads_entry.get().strip())
                if max_workers <= 0:
                    raise ValueError
            except ValueError:
                max_workers = 80
                self.log("⚠️ Invalid thread count. Using default: 80")

            try:
                timeout = float(self.timeout_entry.get().strip())
                if timeout <= 0:
                    raise ValueError
            except ValueError:
                timeout = 3.0
                self.log("⚠️ Invalid timeout. Using default: 3.0s")

            filter_mode = self.filter_combo.get()
            test_mode = self.mode_combo.get()

            script_dir = os.path.dirname(os.path.abspath(__file__))
            xray_path = os.path.join(script_dir, "Core", "xray", "xray.exe")
            singbox_path = os.path.join(script_dir, "Core", "sing_box", "sing-box.exe")
            
            # Check if selected core binaries exist
            if test_mode == "Xray Core (Real Delay & Speed)":
                if not os.path.exists(xray_path):
                    self.log("❌ Error: xray.exe not found in Core/xray/ folder!")
                    self.set_status("Scan aborted: xray.exe missing")
                    return
            elif test_mode == "Sing-box Core (Real Delay & Speed)":
                if not os.path.exists(singbox_path):
                    self.log("❌ Error: sing-box.exe not found in Core/sing_box/ folder!")
                    self.set_status("Scan aborted: sing-box.exe missing")
                    return

            if filter_mode == "Only sub*.txt files":
                file_filter = lambda f: f.startswith("sub") and f.endswith(".txt")
            else:
                file_filter = lambda f: f.endswith(".txt")

            files = [
                os.path.join(self.folder_path, f)
                for f in os.listdir(self.folder_path)
                if file_filter(f) and os.path.isfile(os.path.join(self.folder_path, f))
            ]

            if not files:
                self.log("⚠️ No matching txt files found")
                self.set_status("Scan aborted: No files found")
                return

            self.log(f"📄 Found {len(files)} files to scan.")

            results = {
                "vmess": [],
                "vless": [],
                "ss": [],
                "trojan": []
            }

            links = []

            # 2. Extract and decode files
            for file in files:
                if not self.check_pause_and_stop():
                    break
                self.log(f"📁 Reading {os.path.basename(file)}")
                try:
                    with open(file, "r", encoding="utf-8", errors="ignore") as f:
                        raw_content = f.read()
                    
                    decoded_content = try_decode_base64_content(raw_content)
                    links.extend(LINK_RE.findall(decoded_content))
                except Exception as e:
                    self.log(f"❌ Error reading {os.path.basename(file)}: {str(e)}")

            # Remove duplicate links
            unique_links = list(set(links))
            total_links = len(unique_links)
            self.log(f"🔗 Total unique links: {total_links}")

            if total_links == 0:
                self.log("⚠️ No links found to process.")
                self.set_status("Scan finished: 0 links found")
                return

            # 3. Test latency using ThreadPoolExecutor
            completed = 0
            fast_count = 0
            normal_count = 0
            offline_count = 0

            executor = ThreadPoolExecutor(max_workers=max_workers)
            futures = [executor.submit(self.process_link, link, timeout, test_mode, xray_path, singbox_path) for link in unique_links]

            for f in as_completed(futures):
                # Check stop states and cancel executor tasks asynchronously
                if self.scan_state == "stopping":
                    executor.shutdown(wait=False, cancel_futures=True)
                    self.log("🛑 Scan aborted by user. Results discarded.")
                    break
                elif self.scan_state == "stopping_save":
                    executor.shutdown(wait=False, cancel_futures=True)
                    self.log("💾 Scan stopped by user. Saving completed results...")
                    break
                    
                # Handle pause state in the coordinator loop
                while self.scan_state == "paused":
                    time.sleep(0.2)

                completed += 1
                try:
                    res = f.result()
                except Exception:
                    res = None
                    
                if res:
                    proto, data = res
                    results[proto].append(data)
                    
                    latency = data["latency"]
                    speed = data.get("speed", 0)
                    remark = data.get("remark", "NoRemark")
                    
                    # Log detailed speed & delay info for core modes
                    if "Core" in test_mode:
                        speed_str = f" | ⬇ {speed:.1f} KB/s" if speed > 0 else ""
                        self.log(f"✅ {remark} → ⏱ {latency}ms{speed_str}")
                    
                    if latency < 200:
                        self.fast_nodes.append(data)
                        fast_count += 1
                    else:
                        self.normal_nodes.append(data)
                        normal_count += 1
                else:
                    offline_count += 1

                pct = completed / total_links
                self.set_progress(pct)
                self.set_status(f"Scanned: {completed}/{total_links} ({pct*100:.1f}%)")
                self.update_live_stats(fast_count, normal_count, offline_count)

            if self.scan_state != "stopping":
                # Sort configurations by latency for copying
                self.fast_nodes.sort(key=lambda x: x["latency"])
                self.normal_nodes.sort(key=lambda x: x["latency"])
                
                self.fast_links = [item["link"] for item in self.fast_nodes]
                self.normal_links = [item["link"] for item in self.normal_nodes]

                # 4. Save results
                self.save(results)
                self.log(f"\n📊 Scan Statistics:")
                for proto, items in results.items():
                    self.log(f"  - {proto.upper()}: {len(items)} nodes active")
                self.log("\n✅ DONE!")
                self.set_status("Scan completed successfully")
            else:
                self.set_status("Scan aborted")

        except Exception as e:
            self.log(f"💥 Scanning error occurred: {str(e)}")
            self.set_status("Scan failed")
        finally:
            if executor is not None:
                executor.shutdown(wait=False, cancel_futures=True)
            self.scan_state = "idle"
            self.set_button_states("normal", "normal")
            self.set_copy_buttons_state("normal")
            self.set_control_buttons_state("disabled", "disabled", "disabled")

    # ---------------- PROCESS LINK ----------------
    def process_link(self, link, timeout, test_mode, xray_path, singbox_path):
        try:
            if not self.check_pause_and_stop():
                return None

            if link.startswith("vmess://"):
                host, port, remark, is_tls, security_mode, sni, proto, credentials, transport_type, path, host_header, flow = self.decode_vmess(link)
            else:
                host, port, remark, is_tls, security_mode, sni, proto, credentials, transport_type, path, host_header, flow = self.decode_other(link)

            if not host or not port:
                return None

            # Socket-based fast check
            if test_mode == "TCP / TLS (Ultra Fast)":
                latency = self.ping(host, port, timeout, is_tls, sni)
                if latency is None or latency > 800:
                    return None
                return proto, {
                    "link": link,
                    "remark": remark or "NoRemark",
                    "latency": latency,
                    "speed": 0
                }

            # Real HTTP / Download Speed check using core binaries
            if not self.check_pause_and_stop():
                return None

            import subprocess
            local_port = get_free_port()

            if test_mode == "Xray Core (Real Delay & Speed)":
                config_data = make_xray_config(
                    proto, host, port, credentials,
                    security_mode, is_tls, sni,
                    transport_type, path, host_header,
                    local_port, flow
                )
                binary_path = xray_path
                args = [binary_path, "-c"]
            else:
                config_data = make_singbox_config(
                    proto, host, port, credentials,
                    security_mode, is_tls, sni,
                    transport_type, path, host_header,
                    local_port, flow
                )
                binary_path = singbox_path
                args = [binary_path, "run", "-c"]

            config_filename = f"temp_config_{local_port}.json"
            config_filepath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Core", config_filename)

            # Write temp config
            with open(config_filepath, "w", encoding="utf-8") as f:
                json.dump(config_data, f)

            if not self.check_pause_and_stop():
                try:
                    os.remove(config_filepath)
                except:
                    pass
                return None

            # Spawn core subprocess without window
            CREATE_NO_WINDOW = 0x08000000
            proc = subprocess.Popen(
                args + [config_filepath],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=CREATE_NO_WINDOW
            )

            # Wait for proxy binding
            time.sleep(0.8)

            latency = None
            speed = 0.0

            try:
                if self.check_pause_and_stop():
                    proxy_url = f"http://127.0.0.1:{local_port}"
                    proxy_handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
                    opener = urllib.request.build_opener(proxy_handler)

                    # Test Delay using a lightweight HTTP probe
                    start_time = time.time()
                    probe_url = "http://cp.cloudflare.com/generate_204"
                    req = urllib.request.Request(probe_url, headers={"User-Agent": "Mozilla/5.0"})
                    with opener.open(req, timeout=timeout) as response:
                        if response.getcode() in [204, 200]:
                            latency = int((time.time() - start_time) * 1000)

                    # Test Download Speed with a small fixed payload
                    if latency is not None and latency <= 1500 and self.check_pause_and_stop():
                        download_url = "https://speed.cloudflare.com/__down?bytes=200000"
                        dl_start = time.time()
                        dl_req = urllib.request.Request(download_url, headers={"User-Agent": "Mozilla/5.0"})
                        with opener.open(dl_req, timeout=max(timeout, 8.0)) as response:
                            dl_data = response.read(200000)
                        dl_duration = time.time() - dl_start
                        if dl_duration > 0 and len(dl_data) >= 1024:
                            speed = len(dl_data) / 1024 / dl_duration  # KB/s
                        else:
                            speed = 0.0
            except Exception:
                pass
            finally:
                # Terminate subprocess safely
                try:
                    proc.terminate()
                    proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                    except:
                        pass
                
                # Delete config file
                try:
                    if os.path.exists(config_filepath):
                        os.remove(config_filepath)
                except:
                    pass

            if latency is None or latency > 1500:
                return None

            return proto, {
                "link": link,
                "remark": remark or "NoRemark",
                "latency": latency,
                "speed": speed
            }

        except Exception:
            return None

    # ---------------- DECODERS ----------------
    def decode_vmess(self, link):
        try:
            # Strip fragment, query params and leading scheme
            raw_b64 = link[8:].split('#')[0].split('?')[0]
            raw_b64 = re.sub(r'\s+', '', raw_b64)
            missing_padding = len(raw_b64) % 4
            if missing_padding:
                raw_b64 += '=' * (4 - missing_padding)
            
            raw = base64.b64decode(raw_b64).decode('utf-8', errors='ignore')
            data = json.loads(raw)
            
            host = data.get("add")
            port = data.get("port")
            remark = data.get("ps", "")
            
            if port is not None:
                port = int(port)
                
            tls_val = str(data.get("tls", "")).lower()
            is_tls = tls_val in ["tls", "xtls"] or port == 443
            security_mode = tls_val if tls_val in ["tls", "xtls"] else ("tls" if port == 443 else "none")
            sni = data.get("sni") or data.get("host") or host
            
            credentials = data.get("id")
            transport_type = data.get("net", "tcp").lower()
            path = data.get("path", "")
            host_header = data.get("host", "")
            flow = data.get("flow", "")
            
            return host, port, remark, is_tls, security_mode, sni, "vmess", credentials, transport_type, path, host_header, flow
        except Exception:
            return None, None, "", False, "none", None, "vmess", None, None, None, None, ""

    def decode_other(self, link):
        try:
            main_part = link.split("#")[0]
            remark = unquote(link.split("#")[-1]) if "#" in link else ""
            
            p = urlparse(main_part)
            proto = p.scheme
            
            host = p.hostname
            port = p.port
            credentials = ""
            transport_type = "tcp"
            path = ""
            host_header = ""
            
            # Extract ShadowSocks base64 userinfo and host:port if not standard
            if proto == "ss":
                if not host or not port:
                    raw_b64 = main_part[5:].split('?')[0]
                    raw_b64 = re.sub(r'\s+', '', raw_b64)
                    
                    if "@" in raw_b64:
                        # e.g., ss://BASE64_USERINFO@host:port
                        parts = raw_b64.split("@")
                        hostport = parts[1]
                        if ":" in hostport:
                            host = hostport.split(":")[0]
                            port = hostport.split(":")[1]
                        try:
                            userinfo_b64 = parts[0]
                            missing_padding = len(userinfo_b64) % 4
                            if missing_padding:
                                userinfo_b64 += '=' * (4 - missing_padding)
                            credentials = base64.b64decode(userinfo_b64).decode('utf-8', errors='ignore')
                        except:
                            pass
                    else:
                        # e.g., ss://BASE64_USERINFO_AND_HOST
                        try:
                            missing_padding = len(raw_b64) % 4
                            if missing_padding:
                                raw_b64 += '=' * (4 - missing_padding)
                            decoded = base64.b64decode(raw_b64).decode('utf-8', errors='ignore')
                            if "@" in decoded:
                                userinfo_hostport = decoded.split("@")
                                hostport = userinfo_hostport[-1]
                                if ":" in hostport:
                                    host = hostport.split(":")[0]
                                    port = hostport.split(":")[1].split("/")[0]
                                credentials = userinfo_hostport[0]
                        except Exception:
                            pass
                else:
                    # Standard ss://method:password@host:port
                    userinfo = unquote(p.username) if p.username else ""
                    if ":" in userinfo:
                        credentials = userinfo
                    else:
                        try:
                            raw = userinfo
                            missing_padding = len(raw) % 4
                            if missing_padding:
                                raw += '=' * (4 - missing_padding)
                            decoded = base64.b64decode(raw).decode('utf-8', errors='ignore')
                            credentials = decoded if ":" in decoded else userinfo
                        except Exception:
                            credentials = userinfo
            else:
                credentials = unquote(p.username) if p.username else p.netloc.split("@")[0]
            
            if port is not None:
                port = int(port)
                
            # Parse query parameters for security, SNI, transport, path, host, flow
            q = parse_qs(p.query)
            security = q.get("security", [""])[0].lower()
            if not security and port == 443 and proto in ["vless", "trojan"]:
                security = "tls"
            sni = q.get("sni", [""])[0] or q.get("host", [""])[0] or host
            
            is_tls = False
            if proto in ["vless", "trojan"]:
                is_tls = security in ["tls", "xtls"] or (proto == "trojan" and security != "none")
            
            transport_type = q.get("type", q.get("network", ["tcp"]))[0].lower()
            if transport_type == "grpc":
                path = q.get("serviceName", [""])[0]
            else:
                path = q.get("path", [""])[0]
            
            host_header = q.get("host", [""])[0]
            flow = q.get("flow", [""])[0]
            
            return host, port, remark, is_tls, security, sni, proto, credentials, transport_type, path, host_header, flow
        except Exception:
            return None, None, "", False, "none", None, "vless", None, None, None, None, ""

    # ---------------- LATENCY ----------------
    def ping(self, host, port, timeout, is_tls=False, sni=None):
        try:
            start = time.time()
            s = socket.create_connection((host, port), timeout=timeout)
            
            if is_tls:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                
                ssl_conn = context.wrap_socket(s, server_hostname=sni or host)
                ssl_conn.close()
            else:
                s.close()
                
            return int((time.time() - start) * 1000)
        except Exception:
            return None

    # ---------------- SAVE ----------------
    def save(self, data):
        output_dir = os.path.join(self.folder_path, "Scan_Results")
        try:
            os.makedirs(output_dir, exist_ok=True)
            self.log(f"💾 Saving results inside: {output_dir}")
        except Exception as e:
            self.log(f"❌ Failed to create folder {output_dir}: {str(e)}")
            output_dir = self.folder_path  # fallback

        for proto, items in data.items():
            if not items:
                continue

            items.sort(key=lambda x: x["latency"])

            fast = [
                f"{i['link']} # {i['remark']} - {i['latency']}ms" + (f" - {i['speed']:.1f}KB/s" if i.get("speed", 0) > 0 else "")
                for i in items if i["latency"] < 200
            ]

            normal = [
                f"{i['link']} # {i['remark']} - {i['latency']}ms" + (f" - {i['speed']:.1f}KB/s" if i.get("speed", 0) > 0 else "")
                for i in items if 200 <= i["latency"] <= 800
            ]

            if fast:
                file_path = os.path.join(output_dir, f"fast_{proto}.txt")
                try:
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write("\n".join(fast))
                    self.log(f"  └─ Saved fast {proto} to: {os.path.basename(file_path)}")
                except Exception as e:
                    self.log(f"❌ Error saving {file_path}: {str(e)}")

            if normal:
                file_path = os.path.join(output_dir, f"{proto}.txt")
                try:
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write("\n".join(normal))
                    self.log(f"  └─ Saved {proto} to: {os.path.basename(file_path)}")
                except Exception as e:
                    self.log(f"❌ Error saving {file_path}: {str(e)}")


if __name__ == "__main__":
    app = ConfigScannerApp()
    app.mainloop()