from pathlib import Path
from scanv2ray import parser
from scanv2ray.scanner import Scanner, get_free_port
from scanv2ray import configs
import time, os

link = 'vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogIkBXaGl0ZU5ldF9uZXcg2KzZh9iqINqp2KfZhtmB24zaryDZh9in24wg2KjbjNi02KrYsSDYrNmI24zZhiDYtNmIIiwNCiAgImFkZCI6ICIxNzIuMjMyLjEwMy4xODYiLA0KICAicG9ydCI6ICIyMjMyNCIsDQogICJpZCI6ICIwNDYyMWJhZS1hYjM2LTExZWMtYjkwOS0wMjQyYWMxMjAwMDIiLA0KICAiYWlkIjogIjAiLA0KICAic2N5IjogImF1dG8iLA0KICAibmV0IjogInRjcCIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICIiLA0KICAicGF0aCI6ICIiLA0KICAidGxzIjogIiIsDQogICJzbmkiOiAiIiwNCiAgImFscG4iOiAiIiwNCiAgImZwIjogIiIsDQogICJpbnNlY3VyZSI6ICIwIg0KfQ=='
parsed = parser.parse_link(link)
scanner = Scanner(str(Path('scanv2ray').parent / 'Core' / 'xray' / 'xray.exe'), str(Path('scanv2ray').parent / 'Core' / 'sing_box' / 'sing-box.exe'))

print('parsed ok')
local_port = get_free_port()
print('free port', local_port)
config = configs.make_xray_config(parsed, local_port)
path = scanner._write_config(config)
print('wrote config', path)

valid = scanner._validate_config(scanner.xray_path, path, 'xray')
print('_validate_config returned', valid)
if not valid:
    print('validation failed')
    os.remove(path)
    raise SystemExit(1)

proc = scanner._run_core_process([scanner.xray_path, '-c', path])
print('_run_core_process returned', proc)
if not proc:
    print('failed to launch process')
    os.remove(path)
    raise SystemExit(1)

ok = scanner._wait_for_local_port(local_port, timeout=5.0)
print('_wait_for_local_port ->', ok)

# cleanup
scanner._cleanup_process(proc, path)
print('cleaned up')
