from pathlib import Path
import subprocess
xray = Path('Core/xray/xray.exe')
sing = Path('Core/sing_box/sing-box.exe')
print('xray exists:', xray.exists(), xray.resolve())
print('singbox exists:', sing.exists(), sing.resolve())
for cmd in ([str(xray), '-h'], [str(sing), 'help']):
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
        print('CMD:', cmd, 'RET', p.returncode)
        print('OUT:', p.stdout.decode('utf-8', errors='ignore')[:500])
        print('ERR:', p.stderr.decode('utf-8', errors='ignore')[:500])
    except Exception as e:
        print('EXC:', cmd, e)
