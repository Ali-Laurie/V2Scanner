from scanv2ray.scanner import Scanner
from pathlib import Path
links = [
    'vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogIkBXaGl0ZU5ldF9uZXcg2KzZh9iqINqp2KfZhtmB24zaryDZh9in24wg2KjbjNi02KrYsSDYrNmI24zZhiDYtNmIIiwNCiAgImFkZCI6ICIxNzIuMjMyLjEwMy4xODYiLA0KICAicG9ydCI6ICIyMjMyNCIsDQogICJpZCI6ICIwNDYyMWJhZS1hYjM2LTExZWMtYjkwOS0wMjQyYWMxMjAwMDIiLA0KICAiYWlkIjogIjAiLA0KICAic2N5IjogImF1dG8iLA0KICAibmV0IjogInRjcCIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICIiLA0KICAicGF0aCI6ICIiLA0KICAidGxzIjogIiIsDQogICJzbmkiOiAiIiwNCiAgImFscG4iOiAiIiwNCiAgImZwIjogIiIsDQogICJpbnNlY3VyZSI6ICIwIg0KfQ==',
    'vless://ac7f620c-d491-42a6-9462-6aa82bb7b62b@45.130.125.69:2096?encryption=none&security=tls&sni=SLIPPErY-PrACtICen769XF4bDZ.winDLER.Co.uK&fp=chrome&alpn=h2%2Chttp%2F1.1&insecure=0&allowInsecure=0&type=grpc&authority=&serviceName=irdiplomacy.ir.tehrantimes.com.irna.ir.tasnimnews.com.ifpnews.com.tabnak.ir.donya-e-eqtesad.com&mode=gun#%5B66672%5D',
    'trojan://humanity@104.17.121.71:443?security=tls&sni=www.calmlunch.com&insecure=0&allowInsecure=0&type=ws&host=www.calmlunch.com&path=%2Fassignment#%40meliproxyy',
    'ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTprMWRCT21PQjRvcWk3VW1wMzdhMWJR@82.38.31.208:8080?#%F0%9F%AB%9C91%40oneclickvpnkeys%20%23%20%F0%9F%AB%9C91%40oneclickvpnkeys%20-%20181ms'
]
script_dir = Path(__file__).parent / 'scanv2ray'
xray = str(script_dir.parent / 'Core' / 'xray' / 'xray.exe')
sing = str(script_dir.parent / 'Core' / 'sing_box' / 'sing-box.exe')
print('xray:', xray)
print('sing:', sing)
scanner = Scanner(xray, sing)

for link in links:
    print('\n--- Testing link ---')
    print(link)
    try:
        res = scanner.process_link(link, timeout=6, methods=['fast','xray','singbox'])
        print('Result:', res)
    except Exception as e:
        print('Exception:', e)
