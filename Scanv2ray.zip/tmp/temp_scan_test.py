from pathlib import Path
from scanv2ray.scanner import Scanner

link = 'ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTprMWRCT21PQjRvcWk3VW1wMzdhMWJR@82.38.31.208:8080?#%F0%9F%AB%9C91%40oneclickvpnkeys%20%23%20%F0%9F%AB%9C91%40oneclickvpnkeys%20-%20181ms'
script_dir = Path('.').resolve()
xray = str(script_dir / 'Core' / 'xray' / 'xray.exe')
sing = str(script_dir / 'Core' / 'sing_box' / 'sing-box.exe')
scanner = Scanner(xray, sing)
res = scanner.process_link(link, timeout=6, methods=['fast', 'xray', 'singbox'])
print(res)
