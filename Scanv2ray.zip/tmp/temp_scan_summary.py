from pathlib import Path
from scanv2ray.scanner import Scanner

file_path = Path('D:/sub-test.txt')
assert file_path.exists(), f'Missing {file_path}'

xray = Path('Core/xray/xray.exe')
sing = Path('Core/sing_box/sing-box.exe')
assert xray.exists(), xray
assert sing.exists(), sing

scanner = Scanner(str(xray), str(sing))
links = [line.strip() for line in file_path.read_text(encoding='utf-8', errors='ignore').splitlines() if line.strip()]
summary = {'total': len(links), 'ok': 0, 'dead': 0, 'results': []}

for idx, link in enumerate(links, start=1):
    print(f'[{idx}/{len(links)}] testing: {link}')
    try:
        res = scanner.process_link(link, timeout=6, methods=['fast'])
    except Exception as e:
        print('  EXCEPTION:', e)
        res = []
    if res:
        print('  OK:', res)
        summary['ok'] += 1
        summary['results'].append({'link': link, 'result': res})
    else:
        print('  DEAD')
        summary['dead'] += 1

print('\nSUMMARY:')
print('  total =', summary['total'])
print('  ok    =', summary['ok'])
print('  dead  =', summary['dead'])
print('  ok links:')
for item in summary['results']:
    print(item['link'])
    print(item['result'])
