import json
from pathlib import Path
from scanv2ray.scanner import Scanner
from scanv2ray import parser, configs

links = [
    'vmess://ew0KICAidiI6ICIyIiwNCiAgInBzIjogIkBXaGl0ZU5ldF9uZXcg2KzZh9iqINqp2KfZhtmB24zaryDZh9in24wg2KjbjNi02KrYsSDYrNmI24zZhiDYtNmIIiwNCiAgImFkZCI6ICIxNzIuMjMyLjEwMy4xODYiLA0KICAicG9ydCI6ICIyMjMyNCIsDQogICJpZCI6ICIwNDYyMWJhZS1hYjM2LTExZWMtYjkwOS0wMjQyYWMxMjAwMDIiLA0KICAiYWlkIjogIjAiLA0KICAic2N5IjogImF1dG8iLA0KICAibmV0IjogInRjcCIsDQogICJ0eXBlIjogIm5vbmUiLA0KICAiaG9zdCI6ICIiLA0KICAicGF0aCI6ICIiLA0KICAidGxzIjogIiIsDQogICJzbmkiOiAiIiwNCiAgImFscG4iOiAiIiwNCiAgImZwIjogIiIsDQogICJpbnNlY3VyZSI6ICIwIg0KfQ==',
    'vless://ac7f620c-d491-42a6-9462-6aa82bb7b62b@45.130.125.69:2096?encryption=none&security=tls&sni=SLIPPErY-PrACtICen769XF4bDZ.winDLER.Co.uK&fp=chrome&alpn=h2%2Chttp%2F1.1&insecure=0&allowInsecure=0&type=grpc&authority=&serviceName=irdiplomacy.ir.tehrantimes.com.irna.ir.tasnimnews.com.ifpnews.com.tabnak.ir.donya-e-eqtesad.com&mode=gun#%5B66672%5D',
    'trojan://humanity@104.17.121.71:443?security=tls&sni=www.calmlunch.com&insecure=0&allowInsecure=0&type=ws&host=www.calmlunch.com&path=%2Fassignment#%40meliproxyy',
    'ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTprMWRCT21PQjRvcWk3VW1wMzdhMWJR@82.38.31.208:8080?#%F0%9F%AB%9C91%40oneclickvpnkeys%20%23%20%F0%9F%AB%9C91%40oneclickvpnkeys%20-%20181ms'
]
scanner = Scanner(str(Path('scanv2ray').parent / 'Core' / 'xray' / 'xray.exe'), str(Path('scanv2ray').parent / 'Core' / 'sing_box' / 'sing-box.exe'))

for link in links:
    print('\n=== LINK ===')
    print(link)
    parsed = parser.parse_link(link)
    print('\nparsed:')
    print(json.dumps(parsed, indent=2, ensure_ascii=False))
    if not parsed:
        print('parse failed, skipping')
        continue
    # build xray config
    cfg = scanner._build_config(parsed, 10809, 'xray')
    print('\nGenerated Xray config:')
    print(json.dumps(cfg, indent=2, ensure_ascii=False))
    # write temp config
    path = scanner._write_config(cfg)
    print('\nWrote to', path)
    # run xray -test
    import subprocess
    try:
        res = subprocess.run([scanner.xray_path, '-test', '-c', path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
        print('\nXRAY -test returncode:', res.returncode)
        print('stdout:')
        print(res.stdout.decode('utf-8', errors='ignore'))
        print('stderr:')
        print(res.stderr.decode('utf-8', errors='ignore'))
    except Exception as e:
        print('XRAY test exception:', e)
    finally:
        try:
            import os
            os.remove(path)
        except Exception:
            pass
